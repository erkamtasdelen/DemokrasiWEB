<?php
    header("Access-Control-Allow-Origin: *"); // CORS hatasını önler
    header("Content-Type: application/json"); // JSON formatında veri döndür

    // MySQL bağlantısı
    $servername = "localhost";
    $username = "root"; // MySQL kullanıcı adın
    $password = ""; // MySQL şifren
    $database = "protesto_db"; 

    $conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        die(json_encode(["error" => "Veritabanı bağlantısı başarısız: " . $conn->connect_error]));
    }

    // API metodu kontrolü
    $method = $_SERVER['REQUEST_METHOD'];

    // GET: Şehir listesini çek
    if ($method == "GET") {
        $sql = "SELECT * FROM sehirler";
        $result = $conn->query($sql);
        
        $cities = [];
        while ($row = $result->fetch_assoc()) {
            $cities[] = $row;
        }
        
        echo json_encode($cities);
    }

    // POST: Yeni şehir ekleme
    elseif ($method == "POST") {
        $data = json_decode(file_get_contents("php://input"), true);
        
        if (isset($data['plaka']) && isset($data['sehir']) && isset($data['katilim'])) {
            $plaka = (int) $data['plaka'];
            $sehir = $conn->real_escape_string($data['sehir']);
            $katilim = (int) $data['katilim'];

            $sql = "INSERT INTO sehirler (plaka, sehir, katilim) VALUES ('$plaka', '$sehir', '$katilim')";
            if ($conn->query($sql)) {
                echo json_encode(["message" => "Şehir eklendi!"]);
            } else {
                echo json_encode(["error" => "Ekleme hatası: " . $conn->error]);
            }
        } else {
            echo json_encode(["error" => "Eksik veri"]);
        }
    }

    // DELETE: Şehir silme
    elseif ($method == "DELETE") {
        $data = json_decode(file_get_contents("php://input"), true);
        
        if (isset($data['plaka'])) {
            $plaka = (int) $data['plaka'];

            $sql = "DELETE FROM sehirler WHERE plaka = $plaka";
            if ($conn->query($sql)) {
                echo json_encode(["message" => "Şehir silindi!"]);
            } else {
                echo json_encode(["error" => "Silme hatası: " . $conn->error]);
            }
        } else {
            echo json_encode(["error" => "Eksik veri"]);
        }
    }

    // PATCH: Plaka koduna göre şehre +1 katılımcı ekle
    elseif ($method == "PATCH") {
        $data = json_decode(file_get_contents("php://input"), true);

        if (isset($data['plaka'])) {
            $plaka = (int) $data['plaka'];

            $sql = "UPDATE sehirler SET katilim = katilim + 1 WHERE plaka = $plaka";
            if ($conn->query($sql)) {
                echo json_encode(["message" => "$plaka plakalı şehre +1 kişi eklendi!"]);
            } else {
                echo json_encode(["error" => "Güncelleme hatası: " . $conn->error]);
            }
        } else {
            echo json_encode(["error" => "Eksik veri"]);
        }
    }

    $conn->close();
?>
